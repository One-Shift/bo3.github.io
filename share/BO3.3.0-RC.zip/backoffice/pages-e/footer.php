<?php

/* last thing */
$footer = bo3::c2r([], bo3::loade("footer.tpl"));
