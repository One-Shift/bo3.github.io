<?php

$cfg->email = new stdClass();

$cfg->email->email = ["hello@one-shift.com"];
$cfg->email->smtp = "mail.yourdomain.here";
$cfg->email->username = "your@email.here";
$cfg->email->password = "yourpassword";
$cfg->email->secure = "connection-type eg.: plain";
$cfg->email->port = "connection-port eg.: 25";

$cfg->email->debug = 1;

$cfg->email->support = "hello@one-shift.com";
