<?php

$cfg = new stdClass();
