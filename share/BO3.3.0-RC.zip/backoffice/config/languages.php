<?php

$cfg->lg = [
	1 => [TRUE, "pt", "Português"],
	2 => [TRUE, "en", "English"],
	3 => [FALSE, "spl3", "Sample 3"],
	4 => [FALSE, "spl4", "Sample 4"],
	5 => [FALSE, "spl5", "Sample 5"],
	6 => [FALSE, "spl6", "Sample 6"]
];
