INSERT INTO `{c2r-prefix}_modules` (`folder`, `sort`) VALUES ("{c2r-mod-folder}", 0);
