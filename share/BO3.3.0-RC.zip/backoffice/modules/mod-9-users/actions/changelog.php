<?php

$mdl = bo3::mdl_load("templates-e/changelog.tpl");

include "pages/module-core.php";
