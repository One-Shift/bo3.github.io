<?php

$page_tpl = bo3::load("error/404.tpl");

/* last thing */
$tpl = bo3::c2r([], $page_tpl);
