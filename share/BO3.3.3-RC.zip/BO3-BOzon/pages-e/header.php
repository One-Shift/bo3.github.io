<?php

$page_e_tpl = bo3::loade("header.tpl");

/* last thing */
$header = bo3::c2r([], $page_e_tpl);
