<?php

$cfg->db = new stdClass();

$cfg->db->connect = FALSE; // Database not connected by default. Change to TRUE to connect
$cfg->db->host = "127.0.0.1";
$cfg->db->user = "username";
$cfg->db->password = "password";
$cfg->db->database = "database_name";
$cfg->db->prefix = "prefix";
