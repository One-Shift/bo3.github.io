<?php

if (isset($_GET["i"])) {
	$id = intval($_GET["i"]);
} else {
	$id = null;
}
