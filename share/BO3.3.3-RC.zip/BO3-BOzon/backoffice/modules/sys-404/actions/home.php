<?php

$mdl = bo3::mdl_load("templates/home.tpl");

include "pages/module-core.php";
