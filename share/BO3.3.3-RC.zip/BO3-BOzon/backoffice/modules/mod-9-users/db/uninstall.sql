DELETE FROM `{c2r-prefix}_modules` WHERE `folder` = '{c2r-mod-folder}';

DROP TABLE IF EXISTS `{c2r-prefix}_9_users`;
DROP TABLE IF EXISTS `{c2r-prefix}_9_users_fields`;
