DELETE FROM `{c2r-prefix}_modules` WHERE `folder` = '{c2r-mod-folder}';
