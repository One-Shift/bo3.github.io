DELETE FROM `{c2r-prefix}_modules` WHERE `folder` = '{c2r-mod-folder}';

DROP TABLE IF EXISTS `{c2r-prefix}_8_categories`;
DROP TABLE IF EXISTS `{c2r-prefix}_8_categories_lang`;
